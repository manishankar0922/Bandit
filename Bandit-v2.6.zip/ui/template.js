export const html = `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Bandit — AI Prompt Companion</title>
  <link rel="stylesheet" href="styles.css">

</head>
<body>

<div class="app">
  <div class="topbar">
    <div class="logo"></div>
    <b>VibeBuild</b><span>— untitled-project-7</span>
    <span class="demo-tag">DEMO · Bandit Desktop Pet 🐾</span>
  </div>
  <div class="stage">
    <div id="rocky-root">
  <div class="pet-wrap" id="petWrap">
    <div class="bubble" id="bubble"></div>
    <div class="pet-menu" id="petMenu">
      <button id="menuEnhance">✨ Enhance Prompt</button>
      <button id="menuUndo">↩️ Undo</button>
      <button id="menuSummarize">📋 Summarize Chat</button>
      <button id="menuDisable">🚫 Disable on this site</button>
      <button id="menuSettings">⚙️ Settings</button>
      <button id="menuMore">➕ More...</button>
      <div id="menuExtra" style="display: none; flex-direction: column; gap: 4px; border-top: 1px solid rgba(255,255,255,0.1); padding-top: 4px;">
        <button id="menuHistory">📜 History</button>
        <button id="menuHome">🏠 Go Home (Corner)</button>
        <button id="menuFeed">🍪 Feed Bandit</button>
      </div>
    </div>
    <div class="emote" id="startleEmote" style="display:none;position:absolute;top:-10px;font-size:28px;z-index:10;animation:pop .3s cubic-bezier(.3,1.4,.5,1)">❗️</div>
    <div class="pet" id="pet">
      <span class="zzz">z</span><span class="zzz z2">z</span>
      <span class="spark s1"></span><span class="spark s2"></span><span class="spark s3"></span>
      <div class="sprite" id="frontSprite"><svg viewBox="0 0 32 32" id="frontSvg"></svg></div>
      
      
      
    </div>
  </div>
</div>

<div class="toast" id="toast"></div>

<div class="modal-overlay" id="settingsModal">
  <div class="modal">
    <h3>Bandit Settings</h3>
    
    <div class="xp-bar" style="opacity:1; transform:none; pointer-events:auto; margin:0 0 4px 0; width:100%; max-width:none; background:#0f1318;"><div class="xp-fill" id="xpFill"></div></div>
    <div class="xp-label" id="xpLabel" style="opacity:1; transform:none; pointer-events:auto; margin-bottom:16px;">BANDIT · <b>LVL 1</b> · 0/20 XP</div>

    <label>
      Name
      <input type="text" id="settingName" value="Bandit" autocomplete="off" spellcheck="false" maxlength="32">
    </label>
    <label>
      Size (<span id="sizeValue">100%</span>)
      <input type="range" id="settingSize" min="0.5" max="2" step="0.1" value="1">
    </label>

    <hr class="modal-divider">

    <label style="flex-direction:row;align-items:center;gap:8px;cursor:pointer">
      <input type="checkbox" id="settingAskPlaceholders" style="accent-color:#f5a524">
      Ask me to fill in [placeholders] after Enhance <span class="label-hint">(advanced)</span>
    </label>

    <label>
      Enhance Style
      <select id="settingStyle">
        <option value="structured">Structured (GOAL / CONTEXT / REQUIREMENTS)</option>
        <option value="concise">Concise (one tight paragraph)</option>
        <option value="detailed">Detailed (full spec + edge cases)</option>
      </select>
    </label>

    <label>
      Prompt Tone
      <select id="settingTone">
        <option value="professional">🏢 Professional (default)</option>
        <option value="casual">💬 Casual & Friendly</option>
        <option value="academic">🎓 Academic & Scholarly</option>
        <option value="creative">🎨 Creative & Bold</option>
      </select>
    </label>

    <label>
      AI Provider
      <select id="settingProvider">
        <option value="anthropic">Anthropic Claude</option>
        <option value="openai">OpenAI</option>
        <option value="gemini">Google Gemini</option>
        <option value="groq">Groq (free tier, fast)</option>
        <option value="nvidia">NVIDIA NIM (free tier)</option>
        <option value="builtin">Use built-in Chrome AI only (no key)</option>
      </select>
    </label>
    <label>
      API Key
      <span class="label-hint" id="apiKeyHint">
        <a id="getApiKeyLink" href="#" target="_blank" style="color: #64b5f6;">Get your API key here 🔗</a>
      </span>
      <input type="password" id="settingApiKey" autocomplete="off" spellcheck="false" placeholder="paste your key">
    </label>
    <label>
      Model <span class="label-hint">(optional override)</span>
      <input type="text" id="settingModel" autocomplete="off" spellcheck="false" placeholder="defaults to a fast/cheap model">
    </label>
    <div class="settings-row">
      <button id="testApiKey" type="button" class="secondary">Test key</button>
      <span id="testApiKeyStatus" class="test-key-status"></span>
    </div>

    <div class="settings-row" style="margin-top: 12px; display: flex; justify-content: space-between; align-items: center;">
      <button id="resetDisabledSites" type="button" class="secondary" style="font-size: 11px;">Reset disabled sites</button>
      <span id="resetDisabledStatus" style="font-size: 11px; color: var(--green);"></span>
    </div>

    <div style="text-align: center; margin-top: 4px;">
      <a href="https://github.com/manishankar0922/Bandit/blob/main/PRIVACY.md" target="_blank" style="font-size: 11px; color: var(--dim); text-decoration: underline;">Privacy Policy</a>
    </div>

    <hr class="modal-divider">

    <div style="display: flex; gap: 8px; justify-content: center;">
      <button id="exportSettings" type="button" class="secondary" style="font-size: 11px;">💾 Export Backup</button>
      <button id="importSettings" type="button" class="secondary" style="font-size: 11px;">📂 Import Backup</button>
    </div>
    <span id="backupStatus" style="font-size: 11px; color: var(--green); text-align: center; display: block;"></span>

    <button id="closeSettings">Save & Close</button>
  </div>
</div>

<script src="storage.js"></script>
<script src="ai/prompts.js"></script>
<script src="ai/pipeline.js"></script>


<script src="ui/injector.js"></script>
<script src="ui/modals.js"></script>
<script src="ui/popup.js"></script>
<script src="pet/core.js"></script>
<script src="demo.js"></script>

</body>
</html>
`;
export const css = `:root,:host{
    --bg:#0f1318;
    --panel:#161c24;
    --panel-2:#1d242e;
    --line:#2a3340;
    --text:#dce3ec;
    --dim:#8a95a5;
    --amber:#f5a524;
    --amber-soft:rgba(245,165,36,.14);
    --font-mono:'SFMono-Regular',ui-monospace,'Cascadia Mono',Consolas,monospace;
  }
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{height:100%}
  body{
    background:var(--bg);color:var(--text);
    font-family:-apple-system,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;
    overflow:hidden;
  }

  /* ---------- fake vibe-coding tool ---------- */
  .app{display:flex;flex-direction:column;height:100vh}
  .topbar{display:flex;align-items:center;gap:10px;padding:10px 16px;border-bottom:1px solid var(--line);background:var(--panel);flex-shrink:0}
  .logo{width:22px;height:22px;border-radius:6px;background:linear-gradient(135deg,#5b6cff,#9a4dff)}
  .topbar b{font-size:14px}
  .topbar span{font-size:12px;color:var(--dim)}
  .demo-tag{margin-left:auto;font-family:var(--font-mono);font-size:11px;color:var(--amber);background:var(--amber-soft);border:1px solid rgba(245,165,36,.35);padding:3px 8px;border-radius:99px}

  .stage{flex:1;display:flex;min-height:0}
  .chat{flex:1;display:flex;flex-direction:column;max-width:760px;margin:0 auto;width:100%;padding:0 16px}
  .messages{flex:1;overflow-y:auto;padding:20px 4px;display:flex;flex-direction:column;gap:12px}
  .msg{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:12px 14px;font-size:13.5px;line-height:1.55;max-width:88%}
  .msg.ai{align-self:flex-start;color:var(--dim);white-space:pre-wrap}
  .msg.you{align-self:flex-end;background:var(--panel-2);white-space:pre-wrap;font-family:var(--font-mono);font-size:12.5px}
  .msg .who{font-size:10px;text-transform:uppercase;letter-spacing:1px;color:var(--dim);margin-bottom:6px;font-family:var(--font-mono)}
  .msg.enhanced{border-color:rgba(245,165,36,.4)}
  .msg.enhanced .who{color:var(--amber)}
  .cursor { animation: blink 1s step-end infinite; color: var(--amber); }
  @keyframes blink { 50% { opacity: 0; } }

  .composer{flex-shrink:0;padding:12px 4px 18px}
  .composer-box{background:var(--panel);border:1px solid var(--line);border-radius:14px;padding:12px;display:flex;flex-direction:column;gap:10px;transition:border-color .25s, box-shadow .25s}
  .composer-box.rocky-glow{border-color:rgba(245,165,36,.55);box-shadow:0 0 0 1px rgba(245,165,36,.2), 0 8px 32px rgba(245,165,36,.08)}
  textarea{background:transparent;border:none;outline:none;resize:none;color:var(--text);font-family:var(--font-mono);font-size:13px;line-height:1.55;min-height:64px;max-height:200px}
  textarea::placeholder{color:#57616f}
  .composer-actions{display:flex;align-items:center;gap:8px}
  .hint{font-size:11.5px;color:var(--dim);font-family:var(--font-mono)}
  .send{margin-left:auto;background:var(--panel-2);border:1px solid var(--line);color:var(--text);font-size:12.5px;padding:7px 16px;border-radius:9px;cursor:pointer}
  .send:hover{border-color:#3a4656}

  /* ---------- Rocky ---------- */
  #rocky-root{
    all:initial;
    font-family:var(--font-mono);
    color:var(--text);
    font-size:14px;
    line-height:1.5;
    position:fixed;z-index:2147483647;right:32px;bottom:110px;
    user-select:none;-webkit-user-select:none;touch-action:none;
    will-change: transform, left, top;
  }
  .pet-wrap{position:relative;cursor:grab;display:flex;flex-direction:column;align-items:center}
  .pet-wrap.dragging{cursor:grabbing}
  .pet-wrap.dragging .pet{transform-origin:top center;animation:dangle 1.2s ease-in-out infinite}
  
  
  @keyframes dangle{
    0%,100%{transform:rotate(-6deg) scale(0.92, 1.08)}
    50%{transform:rotate(6deg) scale(0.96, 1.12)}
  }

  .bubble{
    position:absolute;bottom:calc(100% + 12px);right:-8px;
    background:#f4efe4;color:#232323;
    font-family:var(--font-mono);font-size:11.5px;line-height:1.45;
    padding:8px 11px;border-radius:10px;border-bottom-right-radius:3px;
    max-width:210px;width:max-content;
    box-shadow:0 8px 24px rgba(0,0,0,.45);
    opacity:0;transform:translateY(6px) scale(.94);
    transition:opacity .22s,transform .22s;pointer-events:none;
  }
  .bubble::after{content:'';position:absolute;top:100%;right:16px;border:6px solid transparent;border-top-color:#f4efe4}
  .bubble.show{opacity:1;transform:translateY(0) scale(1)}
  .bubble .xp-pop{color:#0b7a3e;font-weight:700}

  .pet-menu{position:absolute;top:10px;left:100%;padding-left:12px;display:flex;flex-direction:column;gap:6px;opacity:0;pointer-events:none;transform:translateX(-6px);transition:opacity .25s .1s,transform .25s .1s;z-index:2}
  .pet-wrap.show-menu .pet-menu{opacity:1;pointer-events:auto;transform:translateX(0);transition:opacity .2s,transform .2s}
  .pet-menu button{background:#1d242e;color:var(--text);border:1px solid var(--line);font-family:var(--font-mono);font-size:12px;padding:8px 12px;border-radius:8px;cursor:pointer;white-space:nowrap;box-shadow:0 4px 12px rgba(0,0,0,.3)}
  .pet-menu button:hover{border-color:var(--amber);color:var(--amber);background:#242c37}

  /* pet stage holds BOTH sprites; only one visible at a time */
  .pet{width:118px;height:118px;position:relative;filter:drop-shadow(0 8px 12px rgba(0,0,0,.5));zoom:var(--pet-scale, 1);will-change:transform}
  .sprite{position:absolute;inset:0;display:flex;align-items:flex-end;justify-content:center}
  .sprite svg{image-rendering:pixelated;shape-rendering:crispEdges;overflow:visible}
  #frontSprite svg, #dangleSprite svg {width:112px;height:112px}
  #sideSprite svg{width:140px;height:78px;transition:transform .12s}
  #sleepSprite svg{width:118px;height:74px}
  #sideSprite, #sleepSprite, #dangleSprite {display:none !important}
  .pet.face-left #frontSprite svg{transform:scaleX(-1)}
  
  .pet-wrap.running .pet{animation:waddle .35s ease-in-out infinite}
  .pet-wrap.running #frontSprite .tail{animation:waddle-tail .35s ease-in-out infinite}
  @keyframes waddle{0%,100%{transform:translateY(0) rotate(-6deg)}50%{transform:translateY(-12px) rotate(6deg)}}
  @keyframes waddle-tail{0%,100%{transform:rotate(15deg)}50%{transform:rotate(-10deg)}}

  .pet-wrap.scooting .pet{animation:scoot .15s linear infinite}
  .pet-wrap.scooting #frontSprite .tail{animation:scoot-tail .15s linear infinite}
  @keyframes scoot{0%,100%{transform:translateY(0) scale(1,1)}50%{transform:translateY(3px) scale(1.06,.94)}}
  @keyframes scoot-tail{0%,100%{transform:rotate(0)}50%{transform:rotate(8deg)}}

  .pet-wrap.hopping .pet{animation:hop-run .5s cubic-bezier(.3,1.4,.5,1) infinite}
  .pet-wrap.hopping #frontSprite .tail{animation:waddle-tail .5s ease-in-out infinite}
  @keyframes hop-run{0%,100%{transform:translateY(0)}50%{transform:translateY(-24px) scale(.95,1.05)}}

  /* ---------- FRONT sprite states (the classic Rocky) ---------- */
  #frontSprite .body-group{transform-origin:50% 90%;animation:breathe 3.2s ease-in-out infinite}
  @keyframes breathe{0%,100%{transform:scaleY(1)}50%{transform:scaleY(1.028)}}
  #frontSprite .tail{transform-origin:18% 88%;animation:f-tail 4s ease-in-out infinite}
  @keyframes f-tail{0%,100%{transform:rotate(0deg)}50%{transform:rotate(-7deg)}}

  .pet-wrap.alert .pet{animation:hop-small .55s ease}
  .pet-wrap.alert #frontSprite .tail{animation:f-tail 1.1s ease-in-out infinite}
  .pet-wrap.alert #frontSprite .ears{animation:ear-perk .5s ease forwards}
  @keyframes ear-perk{to{transform:translateY(-2px)}}
  @keyframes hop-small{0%,100%{transform:translateY(0)}35%{transform:translateY(-8px)}}

  .pet-wrap.working .pet{animation:rummage .5s ease-in-out infinite}
  .pet-wrap.working #frontSprite .tail{animation:f-tail .5s ease-in-out infinite}
  @keyframes rummage{0%,100%{transform:rotate(0deg)}25%{transform:rotate(-2.4deg) translateX(-1px)}75%{transform:rotate(2.4deg) translateX(1px)}}

  .pet-wrap.happy .pet{animation:jump .9s cubic-bezier(.3,1.4,.5,1)}
  @keyframes jump{
    0%{transform:translateY(0) scale(1,1)}
    12%{transform:translateY(2px) scale(1.08,.9)}
    40%{transform:translateY(-26px) scale(.95,1.06)}
    70%{transform:translateY(0) scale(1.05,.94)}
    85%{transform:translateY(-6px) scale(1,1)}
    100%{transform:translateY(0) scale(1,1)}
  }

  .pet-wrap.sleeping .pet{animation:loaf-snooze 4.5s ease-in-out infinite; transform-origin: bottom center}
  
  
  
  @keyframes loaf-snooze{
    0%,100%{transform:scaleY(1) translateY(0)}
    50%{transform:scaleY(0.96) translateY(1px)}
  }
  .zzz{position:absolute;top:-6px;right:2px;font-family:var(--font-mono);color:#7f8ea3;font-size:13px;opacity:0;pointer-events:none}
  .pet-wrap.sleeping .zzz{animation:zfloat 2.6s ease-in-out infinite; top:28px; right:12px}
  .pet-wrap.sleeping .zzz.z2{animation-delay:1.3s;font-size:10px; top:34px; right:2px}
  @keyframes zfloat{
    0%{opacity:0;transform:translateY(0)}
    30%{opacity:1}
    100%{opacity:0;transform:translateY(-20px)}
  }
  
  /* Fetch & Petting & Startle Interactions */
  .fetch-apple { position: fixed; font-size: 24px; user-select: none; pointer-events: none; animation: drop-in 0.4s cubic-bezier(0.3, 1.4, 0.5, 1); z-index: 1000; }
  @keyframes drop-in { 0% { transform: translateY(-40px) scale(0); opacity: 0; } 100% { transform: translateY(0) scale(1); opacity: 1; } }
  
  .heart { position: fixed; color: #ff4b4b; font-size: 16px; pointer-events: none; animation: float-heart 1s ease-out forwards; z-index: 100; }
  @keyframes float-heart { 0% { opacity: 0; transform: translateY(0) scale(0.5); } 20% { opacity: 1; transform: translateY(-10px) scale(1.2); } 100% { opacity: 0; transform: translateY(-30px) scale(1); } }
  
  .pet-wrap.startled .pet { animation: jump-startle 0.4s cubic-bezier(0.3, 1.4, 0.5, 1); }
  .pet-wrap.startled #frontSprite { display: flex !important; }
  .pet-wrap.startled #sleepSprite, .pet-wrap.startled #sideSprite, .pet-wrap.startled #dangleSprite { display: none !important; }
  @keyframes jump-startle { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-35px); } }

  .pet-wrap.spinning .pet{animation:spin-trick .7s cubic-bezier(.3,1.2,.5,1)}
  @keyframes spin-trick{
    0%{transform:rotate(0) translateY(0) scale(1)}
    50%{transform:rotate(180deg) translateY(-22px) scale(1.08)}
    100%{transform:rotate(360deg) translateY(0) scale(1)}
  }

  .pet-wrap.levelup .pet{animation:jump .9s cubic-bezier(.3,1.4,.5,1), glowpulse 1.4s ease}
  @keyframes glowpulse{0%,100%{filter:drop-shadow(0 8px 12px rgba(0,0,0,.5))}40%{filter:drop-shadow(0 0 22px rgba(245,165,36,.9))}}

  .spark{position:absolute;width:7px;height:7px;background:var(--amber);opacity:0;pointer-events:none}
  .pet-wrap.happy .spark{animation:sparkle .85s ease-out forwards}
  .spark.s1{top:8px;left:6px}
  .spark.s2{top:0;right:14px;animation-delay:.12s !important}
  .spark.s3{top:34px;right:-6px;animation-delay:.22s !important}
  @keyframes sparkle{0%{opacity:0;transform:scale(0) rotate(0)}40%{opacity:1;transform:scale(1.25) rotate(45deg)}100%{opacity:0;transform:scale(.4) rotate(90deg) translateY(-14px)}}

  /* (Side sprite removed; using classic front sprite waddle) */

  .xp-bar{margin-top:8px;height:8px;width:100%;max-width:118px;border-radius:99px;background:#242c37;border:1px solid var(--line);overflow:hidden}
  .xp-fill{height:100%;width:0%;background:linear-gradient(90deg,var(--amber),#ffcf6b);transition:width .6s cubic-bezier(.2,.9,.3,1)}
  .xp-label{margin-top:5px;text-align:center;font-family:var(--font-mono);font-size:10px;color:var(--dim);letter-spacing:.4px}
  .xp-label b{color:var(--amber);font-weight:700}
  
  .xp-bar, .xp-label { opacity: 0; transition: opacity .3s; pointer-events: none; }
  .pet-wrap.show-menu .xp-bar, .pet-wrap.show-menu .xp-label,
  .pet-wrap.show-xp .xp-bar, .pet-wrap.show-xp .xp-label { opacity: 1; }

  .toast{position:fixed;bottom:24px;left:50%;transform:translateX(-50%) translateY(20px);background:#f4efe4;color:#232323;font-family:var(--font-mono);font-size:12px;padding:9px 14px;border-radius:10px;opacity:0;transition:.3s;z-index:100000;box-shadow:0 10px 30px rgba(0,0,0,.5)}
  .toast.show{opacity:1;transform:translateX(-50%) translateY(0)}

  .intro{position:fixed;top:64px;right:24px;width:260px;z-index:9999;background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:14px;font-size:12px;line-height:1.6;color:var(--dim)}
  .intro b{color:var(--text)}
  .intro ol{margin:8px 0 0 16px}
  .intro li{margin-bottom:4px}
  .intro .close{position:absolute;top:8px;right:10px;cursor:pointer;color:var(--dim);background:none;border:none;font-size:14px}
  @media (max-width:640px){.intro{display:none}}

  .modal-overlay{position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:999999;display:none;align-items:center;justify-content:center;transition:opacity .2s;}
  .modal-overlay.show{display:flex;opacity:1;pointer-events:auto;}
  .modal{background:var(--panel);border:1px solid var(--line);padding:24px;border-radius:16px;width:280px;max-height:80vh;overflow-y:auto;display:flex;flex-direction:column;gap:16px;font-family:var(--font-mono);box-shadow:0 12px 40px rgba(0,0,0,.5);transform:translateY(12px);transition:transform .2s}
  .modal-overlay.show .modal{transform:translateY(0)}
  .modal h3{font-size:16px;margin-bottom:4px;color:var(--text)}
  dialog.modal {
    margin: auto;
    color: var(--text);
  }
  dialog.modal::backdrop {
    background: rgba(0,0,0,.6);
  }
  .modal label{display:flex;flex-direction:column;gap:8px;font-size:12px;color:var(--dim)}
  .modal label .label-hint{opacity:.6;font-size:11px}
  .modal input[type="text"],.modal input[type="password"],.modal select{background:var(--bg);border:1px solid var(--line);color:var(--text);padding:8px 12px;border-radius:8px;font-family:var(--font-mono);font-size:13px;outline:none}
  .modal input[type="text"]:focus,.modal input[type="password"]:focus,.modal select:focus{border-color:var(--amber)}
  .modal input[type="range"]{accent-color:var(--amber);cursor:pointer}
  .modal button{background:var(--amber);color:#0f1318;border:none;padding:10px;border-radius:8px;font-weight:bold;cursor:pointer;margin-top:8px}
  .modal button:hover{background:#ffbb4d}
  .modal button.secondary{background:var(--panel-2);color:var(--text);border:1px solid var(--line);margin-top:0;padding:8px 12px;font-size:12px}
  .modal button.secondary:hover{background:#242c37;border-color:var(--amber)}
  .modal button.secondary:disabled{opacity:.5;cursor:default}
  .modal-divider{border:none;border-top:1px solid var(--line);margin:2px 0}
  .settings-row{display:flex;align-items:center;gap:10px}
  .test-key-status{font-size:11px;color:var(--dim)}
  .test-key-status.ok{color:#3ecf6e}
  .test-key-status.fail{color:#ff6b6b}

  @media (prefers-reduced-motion:reduce){ .pet *,.pet-wrap *{animation:none !important;transition:none !important} }
.pet-wrap.menu-left .pet-menu {
  left: auto;
  right: 100%;
}
`;
