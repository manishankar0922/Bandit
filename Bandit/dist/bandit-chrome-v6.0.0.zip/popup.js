(() => {
  // src/popup.js
  var api = globalThis.browser ?? globalThis.chrome;
  document.addEventListener("DOMContentLoaded", async () => {
    const toggleSite = document.getElementById("toggleSite");
    const resetAll = document.getElementById("resetAll");
    let host = null;
    let tab = null;
    try {
      const tabs = await api.tabs.query({ active: true, currentWindow: true });
      tab = tabs && tabs[0];
      if (tab && tab.url) {
        const u = new URL(tab.url);
        if (u.protocol.startsWith("http")) {
          host = u.hostname;
        }
      }
    } catch (_) {
    }
    if (!host) {
      toggleSite.disabled = true;
      toggleSite.parentElement.style.opacity = "0.5";
    }
    api.storage.local.get(["banditState", "rockyState"], (res) => {
      let state = res && (res.banditState || res.rockyState) || {};
      let disabled = state.disabledSites || [];
      toggleSite.checked = host ? !disabled.includes(host) : false;
      toggleSite.addEventListener("change", () => {
        if (!host) return;
        const isEnabled = toggleSite.checked;
        if (isEnabled) {
          disabled = disabled.filter((h) => h !== host);
        } else {
          if (!disabled.includes(host)) disabled.push(host);
        }
        state.disabledSites = disabled;
        api.storage.local.set({ banditState: state, rockyState: state });
        if (tab && tab.id) {
          api.tabs.sendMessage(tab.id, { type: "ROCKY_TOGGLE", disabled: !isEnabled }).catch(() => {
            if (isEnabled) {
              api.scripting.executeScript({
                target: { tabId: tab.id },
                files: ["content.bundle.js"]
              }).catch((err) => console.error("Could not inject content script:", err));
            }
          });
        }
      });
      resetAll.addEventListener("click", () => {
        state.disabledSites = [];
        api.storage.local.set({ banditState: state, rockyState: state });
        resetAll.textContent = "Cleared!";
        setTimeout(() => {
          resetAll.textContent = "Reset all disabled sites";
        }, 2e3);
        if (host) toggleSite.checked = true;
        if (tab && tab.id && host) {
          api.tabs.sendMessage(tab.id, { type: "ROCKY_TOGGLE", disabled: false }).catch(() => {
            api.scripting.executeScript({
              target: { tabId: tab.id },
              files: ["content.bundle.js"]
            }).catch((err) => console.error("Could not inject content script:", err));
          });
        }
      });
    });
  });
})();
